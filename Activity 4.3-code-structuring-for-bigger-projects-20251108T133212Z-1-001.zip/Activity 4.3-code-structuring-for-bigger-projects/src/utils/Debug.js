import * as dat from 'lil-gui'

export default class Debug
{
    constructor()
    {
        this.active = true
        this.ui = new dat.GUI()
    }
}

